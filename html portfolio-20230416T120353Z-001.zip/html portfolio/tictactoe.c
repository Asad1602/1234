 #include <stdio.h>
#include<stdlib.h>
int main() {
    int a, b, c, d, e, f, g, h, i; // variables to represent each position on the board
    int player = 1; // player 1 goes first
    int winner = 0; // no winner at the start of the game

    // initialize each position on the board to 0 (empty)
    a = b = c = d = e = f = g = h = i = 0;

    // game loop
    while (winner == 0) {
        // print the board
        printf("\n %d | %d | %d ", a, b, c);
        printf("\n---+---+---");
        printf("\n %d | %d | %d ", d, e, f);
        printf("\n---+---+---");
        printf("\n %d | %d | %d \n", g, h, i);

        // get the player's move
        int move;
        printf("Player %d, enter your move (1-9): ", player);
        scanf("%d", &move);

        // update the board with the player's move
        switch (move) {
            case 1:if(a != 1 && a != 2 )
                    {
                        a = player;
                    }else{
                        printf("position occupied");
                        continue;
                    }
            break;
            case 2: if (b != 1 && b != 2)
                    {
                        b = player;
                    }else{
                        printf("position occupied");
                        continue;
                    }
            break;
            case 3: if(c != 1 && c != 2  ){
                        c = player;
                     }else{
                         printf("position occupied");
                        continue;
                     }
            break;
            case 4: if (d != 1 && d != 2)
                    {
                         d = player;
                    }else{
                        printf("position occupied");
                        continue;
            }
            break;
            case 5: if(e != 1 && e != 2)
                    {
                        e = player;
                    }else{
                        printf("position occupied");
                        continue;
                    }
            break;
            case 6:if(f != 1 && f !=2)
                    {
                         f = player;
                    }else{
                        printf("position occupied");
                        continue;
                    }
            break;
            case 7:if (g != 1 && g != 2)
                    {
                         g = player;
                    }else{
                        printf("position occupied");
                        continue;
                    }
             break;
            case 8:if (h != 1 && h != 2)
                    {
                         h = player;
                    }else{
                        printf("position occupied");
                        continue;
                    }
             break;
            case 9:if (i != 1 && i != 2)
                    {
                         i = player;
                    }else{
                        printf("position occupied");
                        continue;
                    }

            break;
            default: printf("Invalid move, try again.\n"); continue;
        }

        // check for a winner
        if ((a == b && b == c && c != 0) || // top row
            (d == e && e == f && f != 0) || // middle row
            (g == h && h == i && i != 0) || // bottom row
            (a == d && d == g && g != 0) || // left column
            (b == e && e == h && h != 0) || // middle column
            (c == f && f == i && i != 0) || // right column
            (a == e && e == i && i != 0) || // diagonal top-left to bottom-right
            (c == e && e == g && g != 0)) { // diagonal top-right to bottom-left
            winner = player;
        }

        // switch to the other player
        player = (player == 1) ? 2 : 1;
    }

    // print the final board and the winner
    printf("\n %d | %d | %d ", a, b, c);
    printf("\n---+---+---");
    printf("\n %d | %d | %d ", d, e, f);
    printf("\n---+---+---");
    printf("\n %d | %d | %d \n", g, h, i);

    printf("Player %d wins!\n", winner);
    system("pause");
    return 0;
}
