
#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<string.h>
/*write a program to convert binary , octal and hexadecimal number to decimal numbers */
int main (){
    int num, digit,base, exponent = 0;
    int decimal = 0;
    int value = 0;
    int length = 0;

    char input [16];
     printf("enter the choice enter base 2 for binary,8 for octal and 16 for hexadecimal\n");
     scanf("%d",&base);

    switch (base)
    {
    // program to convert binary to decimal
    case 2:
     printf("enter the  binary number\n ");
     scanf("%d",&num);


        // condition to run the loop until all the digits are added
    while (num != 0)
    {
         digit = num % 10;
            // checking validity for binary digits
        if (digit != 0 && digit != 1)
        {
            printf("!!!! Invalid number %d !!!!\n",num);
            printf(" !!! run the program again !!!\n");
            return 0;
        }
            // calculating sum of all digits in decimal
       decimal +=digit * pow(base,exponent);
       num /= 10;
       exponent++;
    }
        // printing the decimal number
    printf(" the decimal equivalent  is %d \n",decimal);

    break;
        // program to convert octal to decimal
    case 8 :
         printf("enter the  octal number\n ");
        scanf("%d",&num);

             // condition to run the loop until all the digits are added
        while (num != 0)
        {
            digit = num % 10;
            // checking validity of octal digits
            if (digit >= 8)
            {
                printf(" !!!! Invalid Number %d !!!! \n",num);
                printf(" !!! run the program again !!!\n");
                return 0;
            }
            decimal+= digit * pow (base ,exponent);
            num /= 10;
            exponent++;
        }
        printf(" the decimal equivalent  is %d \n",decimal);
        break;
    case 16 :
         printf("enter the  hexadecimal number\n ");
        scanf("%s",&input);
        int j = 0;
        // to assign whole number to array
        length = strlen(input);
        length--;

        while ( input [j] != 0)
            {// checking validity of hexadecimal number
            if ( input [j]>= '0' && input[j] <= '9')
            {// calculating integers values
                value = input [j] - '0';
            }
           else if ( input [j] >= 'A' && input[j] <= 'F' )
            {// calculating capital alphabets values
                value = input [j] - 'A' + 10;
            }
            else if ( input [j] >= 'a' && input [j] <= 'f' )
            {// calculating lowercase alphabets values
                value = input [j] - 'a' + 10;
            }else {
                printf("!!!! Invalid Number %s!!!!\n ",input);
                printf(" !!! run the program again !!!\n");
                return 0;
            }
            // final calculations for hexadecimal values to decimal values
            decimal += value * pow (base,length);
            length--;
            j++;
             }
        printf(" the decimal equivalent  is %d \n ",decimal);

         break;
    default:
    printf(" !!! Invalid base !!!\n");
    printf(" !!! enter valid base !!!\n");
    printf(" !!! run the program again !!!\n");
    break;
}
system("pause");
}
