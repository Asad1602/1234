#include <stdio.h>
#include <conio.h>

int main(void)
{
    char c1 = '1', c2 = '2', c3 = '3', c4 = '4', c5 = '5', c6 = '6', c7 = '7', c8 = '8', c9 = '9';
    int turn = 1, stop;
    char player, option, player1[50], player2[50];

    printf("Enter name of player 1 : ");
    fgets(player1, 50, stdin);

    printf("Enter name of player 2 : ");
    fgets(player2, 50, stdin);

    while (turn <= 9)
    {
        printf("\n%c | %c | %c\n", c1, c2, c3);
        printf("---------\n");
        printf("%c | %c | %c\n", c4, c5, c6);
        printf("---------\n");
        printf("%c | %c | %c\n", c7, c8, c9);

        // for deciding the turn of which player
        if (turn % 2 == 1)
        {
            printf("Player 1 (O) select your position : ");
            player = 'O';
        }
        else
        {
            printf("Player 2 (X) select your position : ");
            player = 'X';
        }
        option = getche();

        switch (option)
        {
        case '1':
            if (c1 == 'X' || c1 == 'O')
            {
                printf("\nInvalid,Place is already taken.\n");
                continue;
            }
            c1 = player;
            break;
        case '2':
            if (c2 == 'X' || c2 == 'O')
            {
                printf("\nInvalid,Place is already taken.\n");
                continue;
            }
            c2 = player;
            break;
        case '3':
            if (c3 == 'X' || c3 == 'O')
            {
                printf("\nInvalid,Place is already taken.\n");
                continue;
            }
            c3 = player;
            break;
        case '4':
            if (c4 == 'X' || c4 == 'O')
            {
                printf("\nInvalid,Place is already taken.\n");
                continue;
            }
            c4 = player;
            break;
        case '5':
            if (c5 == 'X' || c5 == 'O')
            {
                printf("\nInvalid,Place is already taken.\n");
                continue;
            }
            c5 = player;
            break;
        case '6':
            if (c6 == 'X' || c6 == 'O')
            {
                printf("\nInvalid,Place is already taken.\n");
                continue;
            }
            c6 = player;
            break;
        case '7':
            if (c7 == 'X' || c7 == 'O')
            {
                printf("\nInvalid,Place is already taken.\n");
                continue;
            }
            c7 = player;
            break;
        case '8':
            if (c8 == 'X' || c8 == 'O')
            {
                printf("\nInvalid,Place is already taken.\n");
                continue;
            }
            c8 = player;
            break;
        case '9':
            if (c9 == 'X' || c9 == 'O')
            {
                printf("\nInvalid,Place is already taken.\n");
                continue;
            }
            c9 = player;
            break;
        default:
            break;
        }
        if (c1 == player && c2 == player && c3 == player)
        {
            stop = 1;
            break;
        }
        if (c4 == player && c5 == player && c6 == player)
        {
            stop = 1;
            break;
        }
        if (c7 == player && c8 == player && c9 == player)
        {
            stop = 1;
            break;
        }
        if (c1 == player && c4 == player && c7 == player)
        {
            stop = 1;
            break;
        }
        if (c2 == player && c5 == player && c8 == player)
        {
            stop = 1;
            break;
        }
        if (c3 == player && c6 == player && c9 == player)
        {
            stop = 1;
            break;
        }
        if (c1 == player && c5 == player && c9 == player)
        {
            stop = 1;
            break;
        }
        if (c3 == player && c5 == player && c7 == player)
        {
            stop = 1;
            break;
        }
        turn++;
    }
    if (stop == 1)
    {
        if (player == 'O')
        {

            printf("\n%c | %c | %c\n", c1, c2, c3);
            printf("---------\n");
            printf("%c | %c | %c\n", c4, c5, c6);
            printf("---------\n");
            printf("%c | %c | %c\n", c7, c8, c9);
            printf("\n%s won.\n", player1);
        }
        else
        {
            printf("\n%c | %c | %c\n", c1, c2, c3);
            printf("---------\n");
            printf("%c | %c | %c\n", c4, c5, c6);
            printf("---------\n");
            printf("%c | %c | %c\n", c7, c8, c9);
            printf("\n%s won.\n", player2);
        }
    }
    else
    {
            printf("\n%c | %c | %c\n", c1, c2, c3);
            printf("---------\n");
            printf("%c | %c | %c\n", c4, c5, c6);
            printf("---------\n");
            printf("%c | %c | %c\n", c7, c8, c9);
            printf("\nGame Draw.");
    }
    return 0;
}